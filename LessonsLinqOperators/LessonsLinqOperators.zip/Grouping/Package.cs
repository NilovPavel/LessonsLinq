﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grouping
{
    class Package
    {
        public string Company;
        public double Weight;
        public long TrackingNumber;
    }
}
